let productos = JSON.parse(localStorage.getItem("productos") || "[]");

function guardar() {
  localStorage.setItem("productos", JSON.stringify(productos));
}

// --- FUNCIONES DE PRODUCTOS.HTML ---

function cargarTabla() {
  const tbody = document.querySelector("#tablaProductos tbody");
  if (!tbody) return;

  tbody.innerHTML = "";
  productos.forEach(p => {
    const tr = document.createElement("tr");
    if (p.vendido === "sí") tr.style.background = "#b6f5b6"; 

    tr.innerHTML = `
      <td>${p.producto}</td>
      <td>${p.precioCompra}</td>
      <td>${p.precioVenta || "-"}</td>
      <td>${p.fecha || "-"}</td>
      <td>${p.vendido || "no"}</td>
      <td>${p.notas || ""}</td>
    `;
    tbody.appendChild(tr);
  });
}

// --- FUNCIÓN DE AÑADIR PRODUCTO (PANEL.HTML) ---

const form = document.querySelector("#addForm");
if (form) {
  form.addEventListener("submit", e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));

    productos.push({
      producto: data.producto,
      // Se asegura que los precios sean números para los cálculos
      precioCompra: Number(data.precioCompra), 
      valorVenta: Number(data.valorVenta) || 0, 
      precioVenta: 0,
      fecha: data.fecha,
      vendido: "no",
      notas: data.notas
    });

    guardar();
    form.reset();
    alert("Producto añadido");
  });
}

// --- FUNCIONES DE ESTADISTICAS.HTML (NUEVAS) ---

function calcularEstadisticas() {
  const totalInversion = productos.reduce((sum, p) => sum + p.precioCompra, 0);
  
  const productosVendidos = productos.filter(p => p.vendido === "sí");
  const productosInventario = productos.filter(p => p.vendido === "no");
  
  const totalVentas = productosVendidos.reduce((sum, p) => sum + (p.precioVenta || 0), 0);
  
  const gananciaTotal = productosVendidos.reduce((sum, p) => {
    const venta = p.precioVenta || 0;
    const compra = p.precioCompra || 0;
    return sum + (venta - compra);
  }, 0);
  
  const inversionPendiente = productosInventario.reduce((sum, p) => sum + p.precioCompra, 0);

  return {
    totalProductos: productos.length,
    vendidos: productosVendidos.length,
    inventario: productosInventario.length,
    inversionTotal: totalInversion.toFixed(2),
    ventasTotal: totalVentas.toFixed(2),
    gananciaTotal: gananciaTotal.toFixed(2),
    inversionPendiente: inversionPendiente.toFixed(2)
  };
}

function mostrarEstadisticas() {
  const statsDiv = document.querySelector("#stats");
  if (!statsDiv) return;

  const stats = calcularEstadisticas();

  statsDiv.innerHTML = `
    <h2>Resumen General</h2>
    <table>
      <tr><th>Métrica</th><th>Valor</th></tr>
      <tr><td>Productos Registrados</td><td>${stats.totalProductos}</td></tr>
      <tr><td>Productos Vendidos</td><td>${stats.vendidos}</td></tr>
      <tr><td>En Inventario</td><td>${stats.inventario}</td></tr>
    </table>

    <h2>Resultados Financieros</h2>
    <table>
      <tr><th>Métrica</th><th>Valor</th></tr>
      <tr><td>Inversión Total (Histórica)</td><td>€ ${stats.inversionTotal}</td></tr>
      <tr><td>Ventas Totales</td><td>€ ${stats.ventasTotal}</td></tr>
      <tr><td>Ganancia Total</td><td>€ ${stats.gananciaTotal}</td></tr>
      <tr><td>Inversión Pendiente (Inventario)</td><td>€ ${stats.inversionPendiente}</td></tr>
    </table>
  `;
}

// --- INICIALIZACIÓN ---
// Carga la tabla si estamos en productos.html
cargarTabla(); 

// Muestra las estadísticas si estamos en estadisticas.html
mostrarEstadisticas();